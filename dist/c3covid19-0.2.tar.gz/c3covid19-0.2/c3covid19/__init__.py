from c3covid19.api import c3api
